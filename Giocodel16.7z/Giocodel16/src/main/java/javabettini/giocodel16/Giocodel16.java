package javabettini.giocodel16;

public class Giocodel16 {

    public static void main(String[] args) {
        Frame f = new Frame();
    }
}
